var express = require('express');

var server  = express();

server.use(function (req, res, next) {
  res.set('Cache-control', 'public, max-age=300');
  next();
})


server.use(express.static(__dirname+"/pages"));
server.use(express.static(__dirname+"/css"));
server.use(express.static(__dirname+"/pages/css"));

server.get("/hsbc/home",(req,res)=>{
	console.log('Request received for HSBC Home Page!!')
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>HSBC Home Page</h1>");
	res.write("<h1>Welcome to HSBC</h1>");
	res.end();
});

server.get("/hsbc/accounts",(req,res)=>{
	console.log('Request received for HSBC Accounts Page!!')
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>HSBC Accounts Page</h1>");
	res.write("<h1>Welcome to HSBC Easy Banking</h1>");
	res.end();
});

server.get("/hsbc/car",(req,res)=>{
	console.log('Request received for  HSBC Car Page!!')
	res.sendFile(__dirname+"/pages/car.html");
});

server.get("/hsbc/weather",(req,res)=>{
	console.log('Request received for  HSBC Weather Page!!')
	res.sendFile(__dirname+"/pages/weather.html");
});

server.get("/hsbc/news",(req,res)=>{
	console.log('Request received for  HSBC News Page!!')
	res.sendFile(__dirname+"/pages/news.html");
});

server.get("/hsbc/*",(req,res)=>{
	console.log('Handling Error and Returing  HSBC Error Page!!')
	res.statusCode = 404;
	res.sendFile(__dirname+"/pages/404.html");
});

var PORT = process.argv.slice(2)[0];

server.listen(PORT,()=>{
	console.log(`Node server is listening on ${PORT}!!!`);
});




